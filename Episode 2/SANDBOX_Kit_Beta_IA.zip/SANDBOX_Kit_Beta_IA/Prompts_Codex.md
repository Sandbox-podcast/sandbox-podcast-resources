# SANDBOX / Les prompts à réutiliser

**La Bêta : L'IA derrière le comptoir | 13 octobre 2026**

Ces demandes servent à préparer puis construire un petit outil. Elles ne garantissent pas sa fiabilité. D'abord une simulation fictive ; ensuite, une revue et des connexions réelles. Un abonnement et un prompt ne remplacent pas la gestion des comptes, des droits, des secrets et des sauvegardes.

## 1. À dicter dans ChatGPT pour obtenir un brief

La première phrase est un bon repère, pas une formule magique. Parler normalement, donner un exemple de sa journée et le résultat attendu.

```text
Crée-moi un prompt pour créer un logiciel.

Je suis fleuriste. Aujourd'hui, ma fidélité est sur des cartes papier et
je n'ai pas d'historique facile à retrouver. Je veux un petit site adapté
au téléphone où mes clients peuvent s'inscrire eux-mêmes.

Après un achat déjà payé à ma caisse, je retrouve le client et je saisis
le montant. Chaque euro entier payé donne un point. Cent points permettent
de proposer une remise de cinq euros, utilisable sur un prochain achat
selon des conditions que je validerai. Je veux voir les achats et les points.

Je veux aussi préparer une promotion pour les clients qui ne sont pas venus
depuis 45 jours, mais seulement s'ils ont accepté les SMS et ne se sont pas
désinscrits. Je valide le message, les destinataires et le budget avant tout
envoi. Ne pas accepter les promotions ne doit pas empêcher l'inscription.

Je ne veux pas remplacer ma caisse, faire ma comptabilité ou encaisser en
ligne. Pour commencer, je veux une démonstration avec des personnes fictives,
sans vrais SMS. Aucun fichier clients réel ne sera fourni.

Pose-moi au maximum cinq questions si un point change vraiment la solution.
Puis produis un prompt pour Codex, en français, avec : le contexte, le premier
périmètre, les trois écrans, les règles de calcul, les exclusions, les tests
à faire, les limites et la manière de lancer la démonstration. Identifie les
hypothèses plutôt que d'inventer des règles. Commence petit.
```

## 2. Prompt Codex complet : première version locale

Créer un dossier vide dédié, l'ouvrir dans l'application ou le mode Codex disponible dans sa version de ChatGPT, puis coller ce texte. Ne pas ouvrir tout son disque ou son dossier personnel. Lire les demandes d'autorisation de l'outil avant d'accepter.

```text
Tu m'aides à créer une première version du Comptoir d'Anna, un commerce
fictif, pour une démonstration de podcast. Je ne suis pas développeur.

OBJECTIF
Une petite application web claire et adaptée au téléphone : inscription
client, saisie d'un achat déjà encaissé, points de fidélité et simulation
de campagne SMS. Pas de vrais clients, pas de vrais messages, pas de paiement.

FAÇON DE TRAVAILLER
1. Examine uniquement le dossier courant et les fichiers utiles au projet.
2. Propose un plan court, les hypothèses et cinq questions maximum si nécessaire.
3. Construis d'abord le parcours minimal qui fonctionne, pas une architecture
   complexe. Explique les commandes avant de demander que je les exécute.
4. Ne supprime aucun fichier existant sans me demander. Ne publie rien,
   n'achète rien, n'envoie aucun message et n'active aucun service payant.
5. Choisis une solution simple, portable et maintenable. Consulte les documents
   officiels actuels pour les bibliothèques utilisées ; n'invente pas d'API.
6. Fais des petits changements puis vérifie-les. Ne dis pas qu'un test passe
   si tu ne l'as pas exécuté. Signale ce qui demande mon intervention.

ÉCRANS
A. Page publique du commerce : activité, horaires fictifs et bouton d'inscription.
   Formulaire court, prénom fictif et moyen de contact factice. Information
   sur l'usage des données. Accord SMS distinct, facultatif, non précoché.
B. Espace commerçant simulé : liste des clients fictifs, recherche, fiche avec
   points et historique. Saisie du montant payé et d'une référence d'achat.
   Indique clairement qu'il ne s'agit pas d'une vraie authentification.
C. Campagne SMS simulée : choisir un seuil d'inactivité, afficher les personnes
   incluses et la raison des exclusions, rédiger un message, estimer son coût,
   demander une validation et simuler l'envoi sans aucune requête externe.

RÈGLES DE FIDÉLITÉ POUR CETTE DÉMO
- Stocker les montants en centimes entiers. Refuser zéro, les valeurs négatives,
  les montants invalides et plus de deux décimales.
- Un euro entier effectivement payé donne un point, arrondi vers le bas par
  achat. 38,90 euros donnent 38 points. Les points ne sont pas de l'argent.
- Camille commence avec 62 points. Un achat de 38 euros doit donner 100 points.
- Une référence ne peut être enregistrée qu'une fois, même après un double
  clic. Une annulation ne libère pas la référence pour un nouvel achat.
- À 100 points, une remise fictive de 5 euros peut être consommée une seule
  fois ; cela retire 100 points. La consommation et le journal doivent rester
  cohérents. Ne pas appliquer de paiement ou de réduction réels.
- Annuler un achat crée une correction traçable, jamais une suppression muette.
  Pour la démo, bloquer toute correction qui rendrait le solde négatif après
  une remise et expliquer qu'un cas de remboursement réel exige une politique
  métier validée. Ne pas inventer une politique de production.
- L'inscription n'est pas un achat. Seules les personnes avec achat connu,
  dernier achat datant d'au moins 45 jours, accord SMS actif et sans opposition
  entrent dans le segment de campagne. Un nouvel achat les en retire.
- Aucun calcul de points n'utilise de modèle d'IA.

DONNÉES FICTIVES ET SMS
Utilise Camille Démo (62 points, dernier achat il y a 60 jours, accord SMS),
Sam Démo (34 points, 10 jours, accord), Robin Démo (26 points, 80 jours, refus)
et Julie Démo (10 points, 75 jours, accord). Lina Démo s'inscrit pendant le test
sans accord SMS ni achat. Aucun vrai numéro joignable ne doit être utilisé.

L'estimation de SMS doit distinguer message et segment facturé. Un texte long
ou Unicode peut compter plusieurs segments. Prévoir une configuration de prix,
pas une garantie tarifaire. Mentionner qu'un vrai STOP n'est pas branché.
Le bouton doit dire explicitement SIMULER, pas ENVOYER. Toute modification du
texte ou des destinataires doit invalider la précédente validation.

QUALITÉ
Interface lisible, contrastée, sans décor inutile. Libellés en français,
navigation clavier, focus visible, messages d'erreur précis et version mobile.
Afficher en permanence : SIMULATION LOCALE, DONNÉES FICTIVES, AUCUN SMS RÉEL.
Aucune donnée réelle, aucun secret, aucun traceur. Réinitialisation simple de
la seule démo. Si le stockage du navigateur est indisponible, expliquer la
limite et rester utilisable en mémoire.

TESTS D'ACCEPTATION À EXÉCUTER
Inscription sans accord ; accord non précoché ; 62 + 38 = 100 ; décimales ;
montant invalide ; double clic et référence déjà utilisée ; remise unique ;
annulation et solde ; nouveau client sans achat ; refus SMS ; achat récent ;
message long et Unicode ; prévisualisation modifiée ; aucun appel SMS réel ;
mobile ; clavier ; réinitialisation.

LIVRABLES
Le projet fonctionnel, un README pour débutant, les commandes utiles, le jeu de
données fictives, le résultat réel des tests et les limites connues. Ajouter
une checklist de ce qui manque pour une vraie production. Proposer une petite
prochaine étape, ne pas enchaîner seul sur une publication.
```

## 3. Prompt de passage vers un vrai pilote

Ce prompt vient **après** la démo. Il demande d'abord un plan et une revue. Il n'autorise ni publication, ni import de clients, ni envoi de SMS.

```text
Nous avons validé le parcours sur des données fictives. Prépare le passage
vers un pilote du Comptoir d'Anna, sans le publier et sans importer de clients.
Commence par lire le projet et présenter les lacunes, les choix techniques,
les actions manuelles, les coûts et les risques. Attends mon accord sur le plan.

Architecture envisagée, à confirmer avec la documentation officielle actuelle :
code dans un dépôt GitHub privé, hébergement commercial adapté chez Vercel,
base de données et authentification Supabase, domaine chez OVHcloud. Vercel Hobby
n'est pas une solution gratuite pour une boutique commerciale. Propose des
options sans engager de dépense. La simulation SMS reste le mode par défaut.

EXIGENCES AVANT DE VRAIS CLIENTS
- Séparer développement, préproduction et production. Conserver les données
  fictives hors de la base de production. Définir la région de stockage et
  documenter les prestataires et transferts, sans promettre la conformité
  uniquement parce qu'une région européenne a été choisie.
- Authentifier le commerçant, protéger son compte, gérer son rôle côté
  serveur. Aucun client ne doit pouvoir s'attribuer un rôle administrateur.
- Mettre des droits d'accès et des politiques de sécurité au niveau de la base.
  Aucune lecture publique des fiches clients. Un client A ne voit jamais B.
  Le formulaire public ne permet aucune recherche de numéro ou de personne.
- Prévoir un moyen adapté de vérifier le contact avant de l'activer, un parcours
  de connexion privé et des réponses qui ne révèlent pas si une personne est
  inscrite. Expliquer les coûts éventuels de vérification. Lutter contre les
  inscriptions abusives, les robots et les essais répétés.
- Pour les achats et remises, utiliser des transactions et des contraintes
  d'unicité côté base, pas seulement un bouton désactivé. Tester les requêtes
  concurrentes, les nouvelles tentatives après panne et les droits d'écriture.
- Tenir un journal des opérations. Ne pas calculer les soldes à partir de
  valeurs librement fournies par le navigateur. Valider les entrées serveur.
- Faire valider les conditions de fidélité, les remboursements, la durée de vie
  des points et la nature des achats donnant droit à des points. Ne pas inventer
  silencieusement de règles commerciales. Garder les ventes dans l'outil existant.
- Pour ce pilote, choisir un accord SMS explicite : finalité claire, case
  distincte et vide, preuve horodatée, version du texte et retrait aussi simple.
  Inscription et promotions restent séparées. Prévoir les mentions d'information,
  l'accès, la rectification, l'effacement et des durées de conservation validées.
- Avant tout vrai SMS, avoir un mécanisme STOP opérationnel et synchroniser la
  liste des refus. Refiltrer les destinataires au moment de l'envoi. Vérifier
  les règles du prestataire et la réglementation applicables au moment du projet.
  Prévoir prévisualisation, budget plafonné, validation humaine, gestion des
  erreurs et protection contre le double envoi. Ne jamais tester sur un client.
- Aucune clé secrète dans le navigateur, le code publié, GitHub ou les prompts.
  Utiliser les variables d'environnement et les secrets des plateformes.
  Fournir .env.example avec uniquement des noms, et .gitignore adapté.
  Ne jamais exposer la clé privilégiée Supabase dans le code client.
- Sauvegarder la base séparément de GitHub. Définir fréquence, rétention,
  protection, export et restauration. Faire une restauration de test en
  environnement isolé. Préparer les migrations et un plan de retour arrière.
- Définir qui maintient le service, qui reçoit les alertes, quoi faire en cas
  d'incident et comment exporter les données pour quitter les prestataires.
- Faire vérifier techniquement le projet et les règles de données avant ouverture.

Donne les preuves de test, les limites et une checklist de décision go/no-go.
Toute publication, dépense, import ou activation de SMS réels exige mon accord
explicite, distinct de l'accord pour construire une démo.
```

## 4. Faire évoluer sans tout casser

### Une fonctionnalité à la fois

```text
Je veux ajouter [fonction]. Voici la situation réelle : [exemple]. Le résultat
attendu est [résultat]. Ne change pas le reste. Explique d'abord l'impact sur
les écrans, les données, les droits et les tests. Vérifie que l'état actuel
est enregistré, puis travaille sur une branche distincte. Pas de publication.
```

### Signaler un bug avec un exemple

```text
Sur [écran], je fais [actions]. J'attends [résultat]. J'obtiens [résultat].
Exemple : Camille a 62 points. Un achat de 38 euros doit donner 100 points,
pas 76 points. Reproduis le problème sur des données fictives, ajoute un test
qui le détecte, corrige la cause et relance les tests existants. Ne modifie
pas une base de production et ne masque pas simplement l'erreur à l'écran.
```

### Vérifier les accès

```text
Fais une revue de sécurité de ce projet et dresse la liste des risques, sans
prétendre la remplacer par une certification. Teste les accès anonyme, client A,
client B et commerçant, en appelant aussi directement les points d'entrée
serveur. Vérifie les lectures, écritures, exports, remises et changements de
rôle. Ne te contente pas de cacher des boutons. Cherche les secrets exposés
sans les recopier dans ta réponse. Donne les tests passés, échoués et non faits.
```

### Préparer un retour en arrière

```text
La version stable est [référence]. Le problème observé est [problème].
Analyse les changements depuis cette version. Dis si le problème touche le
code, le schéma de données, les données elles-mêmes ou un service externe.
Propose une marche arrière sans l'exécuter. N'utilise pas de commande destructive,
ne supprime pas d'historique et ne suppose pas qu'une ancienne version de code
est compatible avec la base actuelle. Préserve une sauvegarde vérifiée.
```

## 5. Trois tests à retenir à l'antenne

**Un client refuse les SMS :** il reste dans la fidélité mais pas dans la campagne.

**On clique deux fois sur l'achat :** les points ne comptent qu'une fois.

**Le code revient en arrière :** les données et les messages déjà envoyés ne sont pas magiquement annulés.

## 6. Repères officiels

Les formulations techniques et les coûts doivent être confrontés à la documentation actuelle. Les instructions de sécurité ci-dessus sont un cahier des charges proposé, pas une attestation de conformité.

- [OpenAI : tarifs Codex](https://chatgpt.com/codex/pricing/)
- [OpenAI : utiliser Codex avec son abonnement](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan)
- [OpenAI : démarrage et dossier de travail](https://developers.openai.com/codex/quickstart/)
- [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans)
- [GitHub : annuler une modification](https://docs.github.com/en/desktop/managing-commits/reverting-a-commit-in-github-desktop)
- [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing)
- [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing)
- [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/)
- [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/)
- [OVHcloud : segmentation des SMS et STOP](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/faq-sms)
- [OVHcloud : API SMS et liste de désinscription](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/api-sms-cookbook)
- [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel)
- [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme)