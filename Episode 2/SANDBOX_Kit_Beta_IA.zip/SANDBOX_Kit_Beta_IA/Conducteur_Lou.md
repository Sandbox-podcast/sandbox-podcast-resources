# SANDBOX / La Bêta
## L'IA derrière le comptoir

**Conducteur de Lou Husson | Cible : 25 minutes | 22 slides + 5 annexes**

Version préparée le 13 octobre 2026. Le support présente un prototype limité et une méthode de travail, pas une promesse de mise en production en quatre heures. Aucun site existant n'a été modifié ni publié.

## 1. Le cap de la séquence

**Faire reconnaître un besoin avant de montrer un outil.** Un commerçant doit pouvoir se dire : « C'est exactement ce que je fais aujourd'hui dans mon carnet. » Les noms des logiciels arrivent seulement après les usages et la démonstration.

Le fil rouge : une boutique fictive, Le Comptoir d'Anna. Le client s'inscrit, Anna saisit un achat déjà encaissé, les points progressent, puis Anna prépare une campagne pour les clients inactifs ayant accepté les SMS. La démo ne remplace ni une caisse, ni un logiciel de facturation.

**La distinction qui rend le sujet clair : l'IA aide à construire le logiciel ; il n'est pas nécessaire d'appeler une IA pour calculer des points de fidélité.** Les usages de dictée et de brouillon de devis peuvent se faire manuellement dans ChatGPT. Les intégrer automatiquement dans l'application serait un ajout distinct, avec des coûts et des vérifications supplémentaires.

### Une ouverture prête à dire

> Vous êtes coiffeur, fleuriste, plombier ou commerçant. Vous avez des clients, des demandes qui arrivent un peu partout et des choses que vous ressaisissez. En une demi-journée, on peut viser un premier outil simple : les clients s'inscrivent, vous retrouvez leurs achats et leur fidélité, vous préparez vos relances. Je vais vous montrer à quoi ça ressemble, quels outils utiliser et ce qu'il faut vérifier avant de le confier à de vrais clients.

La slide 2 porte la promesse. Ajouter oralement : « Je parle d'un premier prototype, sur un besoin précis, avec les comptes déjà prêts. » Pas de fausse garantie de délai ou d'autonomie technique.

## 2. Le rythme

Le parcours prévu représente **22 min 45**, démo de 3 minutes comprise. Garder **2 min 15** pour les réactions de Nico et Loïc et une question du chat : **25 minutes au total**. Les durées sont un guide de répétition, pas des mesures de lecture.

| Format | Adaptation |
|---|---|
| 20 minutes | Passer rapidement ou sauter les slides 3, 6, 16 et 21 ; démo de 2 min 30. Parcours de 18 min 55, puis 1 min 05 d'échange. Garder oralement la limite « ne pas refaire la caisse ». |
| 25 minutes | Les 22 slides, la démo de 3 minutes et 2 min 15 d'échange. |
| 30 minutes | Même parcours, puis 5 minutes pour un cas du chat et deux questions. Utiliser les annexes, ne pas ajouter une création de compte en direct. |

### Trois respirations pour les coanimateurs

Après les usages : « Nico, tu en vois un dans les commerces autour de chez toi qui ferait immédiatement sens ? » Durée visée : 30 secondes.

Après la démo : « Loïc, le truc que tu vérifierais avant de le mettre entre les mains d'un vrai commerçant, ce serait quoi ? » Durée visée : 40 secondes.

En conclusion : « Dans le chat : votre métier, la tâche que vous refaites, et ce que vous aimeriez obtenir à la place. » Garder environ une minute pour choisir un exemple.

## 3. Avant d'enregistrer

Ouvrir `SANDBOX_La_Beta.html` dans un navigateur de bureau, puis **P** pour la fenêtre présentateur et **F** pour le plein écran. Les flèches changent de slide. **D** ouvre la démo ; **Échap** la ferme. **O** affiche toutes les slides ; **A** ouvre les annexes. **T** démarre ou met en pause le chronomètre. La touche **N** affiche les notes sur l'écran actuel : ne pas l'utiliser sur une fenêtre partagée.

Partager **uniquement la fenêtre du diaporama**, pas tout l'écran. Le PDF est le plan de secours sans animation. Le PowerPoint contient aussi les notes orales et les sources.

Répéter une fois le passage de la slide 11 à la démo, puis le retour aux slides. Dans la démo, cliquer sur « Réinitialiser » avant chaque répétition. Couper les notifications et masquer les onglets, fichiers et comptes privés. Aucun secret, numéro réel ou fichier clients à l'écran.

Le HTML fonctionne sans connexion pour les slides et la simulation. Les liens vers les sources demandent une connexion. Rien ne s'installe, aucun SMS n'est envoyé. La simulation peut conserver ses seules données fictives dans le navigateur ; sinon elle reste en mémoire pour la session.

### Le plan de secours

Si quelque chose bloque, diagnostiquer **20 secondes maximum**. Dire : « Le principe reste le même, je vous le montre sur les trois écrans. » Revenir aux slides **8, 9 et 10**. Ne pas transformer la séquence en dépannage.

## 4. La démo en trois minutes

| Temps | Action | Ce que tu fais comprendre |
|---|---|---|
| 00:00 - 00:20 | Ouvrir la démo, rappeler qu'elle est fictive et la réinitialiser. | On illustre un parcours, on ne prétend pas développer le produit en direct. |
| 00:20 - 00:55 | Inscrire Lina Démo, sans cocher l'accord SMS. | On peut rejoindre la fidélité sans accepter les promotions. |
| 00:55 - 01:35 | Onglet Achat & points, Camille Démo, 38 euros, référence DEMO-0038. | 62 + 38 = 100 points. Le montant est déjà encaissé ailleurs. |
| 01:35 - 01:50 | Cliquer à nouveau sur le même achat. | Aucun doublon de points ; la même référence est refusée. |
| 01:50 - 02:35 | Campagne SMS, inactivité de 45 jours. Regarder la liste. | Camille vient d'acheter ; Robin n'a pas consenti ; Lina n'a ni achat ni accord. Julie seule est incluse. |
| 02:35 - 03:00 | Valider la prévisualisation puis simuler. Fermer. | Un accord humain précède l'envoi. Ici, aucun SMS réel ne part. |

Ne pas consommer la remise de 5 euros avant d'avoir montré le total de 100 points. La remise et l'annulation d'achat sont des fonctions de réserve pour les questions. La démo n'a pas d'authentification réelle, de base de données distante ni d'intégration SMS.

## 5. Le conducteur slide par slide

Les timecodes ci-dessous suivent les 22 min 45 de parcours, hors interventions des coanimateurs. Les sources servent à préparer le sujet, pas à être lues à l'antenne.


### 01. L'IA derrière le comptoir.

**00:00 - 00:40**


**À dire**

Aujourd'hui, on laisse les grands discours sur l'IA de côté. On va parler d'un coiffeur qui a un trou dans son planning, d'un artisan qui oublie de relancer un devis, d'une commerçante qui ne sait pas comment retrouver ses clients. Mon sujet, c'est : comment se fabriquer un petit outil qui règle un de ces problèmes, sans commencer par apprendre à développer ? Je vais d'abord vous montrer à quoi ça sert, puis comment on s'y prend.


**À faire**

Ouvrir en plein écran. Ne pas commencer par les noms d'outils.


**Transition**

Voilà ce qu'on peut viser.


**Sources :** [Support Sandbox, épisode 001](https://slides.sandboxpodcast.fr/episode-001/index.html)

### 02. Une demi-journée. Un premier outil utile.

**00:40 - 01:40**


**À dire**

En une demi-journée, on peut viser un premier site où vos clients s'inscrivent eux-mêmes, un fichier clients, un historique d'achats et une carte de fidélité. Vous saisissez un montant après le passage en caisse, les points se mettent à jour, et vous préparez une relance. Je parle bien d'un prototype sur un besoin simple, avec les comptes déjà prêts. Ce n'est pas une promesse de logiciel complet, sécurisé et branché à toutes les caisses en quatre heures. Mais on a déjà quelque chose à essayer, plutôt qu'une idée dans un carnet.


**À faire**

Insister sur ce que la personne pourra faire, pas sur la vitesse de génération.


**Transition**

Et il y a une distinction importante.

### 03. L’IA le construit. Votre commerce l’utilise.

**01:40 - 02:25**


**À dire**

On confond souvent deux choses. Utiliser l'IA pour construire un logiciel, et mettre de l'IA dans ce logiciel. Ici, la fidélité fonctionne avec des règles classiques : un montant donne un nombre de points. On n'a pas besoin de demander son avis à un modèle à chaque achat. C'est un choix pour notre projet : le site fonctionnera sans appel d'IA en production. L'abonnement de création et le coût de fonctionnement sont deux sujets différents.


**À faire**




**Transition**

Avant de choisir le logiciel, choisissons le problème.

### 04. Côté commerce : faire revenir les clients.

**02:25 - 03:30**


**À dire**

Un coiffeur peut constituer une liste de personnes qui souhaitent être prévenues quand un créneau se libère. Un boulanger peut rassembler ses précommandes au lieu de jongler entre le téléphone et les messages. Un fleuriste peut préparer une alerte pour les personnes intéressées par un arrivage. Une épicerie peut remplacer la carte qui finit dans la mauvaise poche. Ce sont des pistes de conception, pas des promesses de chiffre d'affaires. Dans chaque cas, on cherche une action concrète et on mesure si elle est vraiment utilisée.


**À faire**

Question possible à Nico : dans ton commerce de quartier, lequel de ces irritants tu vois le plus ? Garder la réponse courte.


**Transition**

Et pour un artisan, l'enjeu est souvent de ne rien oublier.

### 05. Côté artisan : moins de choses à oublier.

**03:30 - 04:35**


**À dire**

Pour un plombier, un formulaire peut recueillir les bonnes informations avant de rappeler. Pas diagnostiquer automatiquement un problème dangereux. Pour un menuisier, on peut dicter les éléments d'une visite et obtenir un brouillon de devis, dont les prix et les quantités restent à vérifier. Un peintre peut centraliser l'avancement et les photos d'un chantier, avec les autorisations nécessaires. Et un réparateur peut préparer les rappels d'entretien. Ce qui m'intéresse, c'est le petit outil entre deux tâches, celui qu'on n'aurait peut-être jamais fait développer.


**À faire**

Préciser qu'un brouillon de devis ne vaut pas validation technique ou commerciale.


**Transition**

Tout créer soi-même n'est pas pour autant une bonne idée.

### 06. Ne refaites pas votre caisse.

**04:35 - 05:20**


**À dire**

Le but n'est pas de recréer tous les logiciels du commerce. Si la caisse fait déjà la fidélité correctement, activons cette fonction. On fabrique quelque chose lorsque le besoin est particulier, mal couvert, et assez simple à vérifier. Pour notre premier essai, on ne touche ni à l'encaissement, ni à la facture officielle. On note un achat déjà encaissé dans un outil séparé. C'est moins spectaculaire qu'un logiciel qui fait tout, mais beaucoup plus raisonnable pour apprendre.


**À faire**




**Transition**

Notre terrain de jeu sera une petite boutique fictive.

### 07. Bienvenue au Comptoir d’Anna.

**05:20 - 06:00**


**À dire**

Voici Anna. Elle tient une petite boutique et veut un système simple. Le client s'inscrit, Anna ajoute le montant d'un achat déjà payé, les points progressent. Pour l'exemple, un euro entier donne un point et cent points permettent d'utiliser une remise de cinq euros. Ce sont nos règles de démo, à revoir selon les marges du commerce. On ne prétend pas qu'une remise de cinq pour cent convient à tout le monde.


**À faire**




**Transition**

Première chose : éviter de recopier les informations.

### 08. Le client s’inscrit. Personne ne recopie.

**06:00 - 06:55**


**À dire**

Le client ouvre un lien depuis un QR code posé au comptoir. Il remplit les informations vraiment utiles au service. On lui explique pourquoi elles sont demandées. Et l'accord pour les SMS commerciaux est séparé : la case est décochée, il peut refuser sans perdre sa carte. Notre démo utilise seulement des identités fictives. Dans la vraie application, voir sa carte et son historique nécessitera un accès personnel sécurisé, pas simplement connaître le numéro de quelqu'un.


**À faire**

Montrer la case facultative. Ne pas afficher de données de vrais clients.


**Transition**

Ensuite, on veut que l'action au comptoir soit très courte.


**Sources :** [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel) ; [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme)

### 09. 38 € encaissés. 38 points ajoutés.

**06:55 - 07:55**


**À dire**

Camille a soixante-deux points. Anna vient d'encaisser trente-huit euros dans sa caisse habituelle. Dans notre outil, elle retrouve Camille, saisit trente-huit, puis valide. Camille passe à cent points : sa remise de cinq euros est disponible. Ce qu'il faut tester, ce n'est pas seulement le beau cas. Que se passe-t-il si Anna clique deux fois ? Si elle saisit un montant négatif ? Si elle annule l'achat ? Ces règles ne doivent pas être laissées au hasard. L'automatisation avec une vraie caisse viendra plus tard, lorsqu'on aura vérifié qu'une connexion est disponible.


**À faire**

Faire retenir 62 + 38 = 100, ce sera le scénario de démo.


**Transition**

Le fichier permet aussi de préparer une relance pertinente.

### 10. Une raison de revenir. Pas du spam.

**07:55 - 08:50**


**À dire**

Au lieu d'envoyer un message à tout le monde, Anna peut préparer une campagne pour les clients qui ne sont pas revenus depuis quarante-cinq jours et qui ont accepté les SMS. Elle voit le texte, les destinataires et le coût avant de valider. La désinscription doit fonctionner et être respectée. La réglementation prévoit certaines exceptions pour des clients existants et des produits similaires, mais notre première version choisit une règle plus simple : accord explicite requis. Dans le direct, nous ne contacterons personne.


**À faire**




**Transition**

On va maintenant regarder ce parcours fonctionner.


**Sources :** [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel) ; [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/) ; [OVHcloud : API SMS et liste de désinscription](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/api-sms-cookbook)

### 11. On passe au comptoir.

**08:50 - 11:50**


**À dire**

Je vous montre une simulation locale déjà préparée pour le direct. Elle illustre le fonctionnement attendu : ce n'est ni un site déployé, ni une preuve que tout le projet a été développé en direct. Premier onglet, j'inscris Lina sans accepter les SMS. Deuxième onglet, je choisis Camille, j'ajoute trente-huit euros : cent points. Troisième onglet, je regarde la campagne des clients inactifs. Camille vient d'acheter, donc elle sort du segment. Robin a refusé les SMS, donc il reste exclu. Je simule l'envoi : aucun SMS ne part. Ce sont ces comportements, plus que l'apparence, qu'on voudra retrouver dans le vrai outil.


**À faire**

D : ouvrir la démo. Réinitialiser. Inscrire Lina sans accord. Caisse : Camille, 38, référence DEMO-0038. Campagne : 45 jours, vérifier les exclusions. Simuler. Fermer la démo. Si blocage > 20 s, revenir aux slides 8-10.


**Transition**

Maintenant, qu'est-ce qu'il y a derrière ce genre d'outil ?

### 12. À chacun son rôle.

**11:50 - 13:00**


**À dire**

ChatGPT peut vous aider à formuler le besoin. Codex est l'agent de développement d'OpenAI : il travaille sur les fichiers et aide à tester. GitHub conserve le code et son historique. Vercel héberge l'application. Il manque souvent une brique dans les explications : la base de données. Ici, on propose Supabase pour les clients, les achats et les accès. Enfin, OVHcloud peut fournir le nom de domaine et les SMS. Ce n'est pas une architecture cent pour cent française : acheter un .fr chez OVHcloud ne change pas l'emplacement des autres services. Au quotidien, Anna n'ouvre que son outil.


**À faire**

Les métaphores servent à expliquer les rôles, pas à garantir une sécurité particulière.


**Transition**

GitHub mérite une minute, parce qu'il évite quelques sueurs froides.


**Sources :** [OpenAI : utiliser Codex avec son abonnement](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan) ; [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) ; [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing) ; [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/) ; [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/)

### 13. Le code est sur GitHub.

**13:00 - 13:50**


**À dire**

Imaginez une série de versions nommées : inscription qui fonctionne, puis fidélité qui fonctionne. On enregistre ces étapes et on les envoie sur un dépôt GitHub privé. Si une modification casse le site, on peut l'annuler et redéployer une version testée. Ce n'est pas automatique : les fichiers non envoyés ne sont pas magiquement en ligne. Et attention, l'historique du code ne restaure pas un client effacé dans la base, ni un SMS déjà envoyé. Les données ont leur propre sauvegarde.


**À faire**

Garder le vocabulaire commit/push pour les questions, pas pour le premier passage.


**Transition**

Et combien coûte l'ensemble ?


**Sources :** [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) ; [GitHub : annuler une modification](https://docs.github.com/en/desktop/managing-commits/reverting-a-commit-in-github-desktop) ; [GitHub : sauvegarder un dépôt](https://docs.github.com/fr/repositories/archiving-a-github-repository/backing-up-a-repository)

### 14. Ce qui coûte. Ce qui ne coûte pas.

**13:50 - 15:15**


**À dire**

L'idée de petits coûts est bonne, mais tout n'est pas gratuit. Le tarif public de Plus est de vingt dollars par mois ; le prix facturé en France est à vérifier au paiement. Codex est inclus, avec des limites. Pro commence à cent dollars, mais ce n'est pas mon choix par défaut pour démarrer. GitHub peut rester gratuit. Pour un commerce, Vercel Hobby ne convient pas : le plan est non commercial. Supabase a une offre gratuite limitée, avec pause possible et sans sauvegarde automatique incluse. Les offres payantes font donc vite apparaître quelques dizaines de dollars par mois. Le domaine .fr reste peu cher ; les SMS se paient au volume. Et le temps de maintenance n'est pas gratuit non plus.


**À faire**

Ne pas convertir $ en € à la volée. Pour les totaux et les SMS longs : annexe 25.


**Transition**

Les comptes sont là. Le plus important, maintenant, c'est la demande.


**Sources :** [OpenAI : tarifs Codex](https://chatgpt.com/codex/pricing/) ; [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) ; [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing) ; [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/) ; [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/) ; [OVHcloud : segmentation des SMS et STOP](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/faq-sms) ; [OpenAI : prix et limites de ChatGPT Plus](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus) ; [OpenAI : les offres ChatGPT Pro](https://help.openai.com/en/articles/9793128-about-chatgpt-pro-tiers)

### 15. Racontez votre journée.

**15:15 - 16:20**


**À dire**

Une méthode très accessible, c'est de commencer par un vocal dans ChatGPT. Vous dites : crée-moi un prompt pour créer un logiciel. Puis vous racontez votre quotidien avec vos mots. Je suis fleuriste, je veux retrouver mes clients, noter leurs achats et préparer une promotion. Demandez-lui de poser quelques questions et de vous proposer une petite première version. La phrase n'a rien de magique. Vous pourriez aussi parler directement à Codex. ChatGPT est simplement utile pour remettre de l'ordre dans une demande qui part dans tous les sens.


**À faire**

Lire l'exemple en prenant la voix d'un utilisateur, pas celle d'un cahier des charges.


**Transition**

Le résultat doit être concret et vérifiable.

### 16. Une bonne demande. Pas une formule magique.

**16:20 - 17:10**


**À dire**

Une bonne demande précise qui utilise l'outil, ce que cette personne fait, ce qu'on ne doit pas construire tout de suite et comment on saura que cela marche. Dire fais-moi un CRM complet, c'est ouvrir trente sujets. Dire fais une inscription, une saisie d'achat et un calcul de points, avec trois tests précis, c'est plus facile à piloter. On peut aussi demander à Codex de signaler ce qui n'est pas branché, plutôt que de faire semblant que le bouton fonctionne.


**À faire**




**Transition**

Ensuite, on passe de la demande aux fichiers.

### 17. Du dossier au site en ligne.

**17:10 - 18:15**


**À dire**

Sur son ordinateur, on crée un dossier pour le projet. Dans l'application ou le mode Codex disponible sur sa version, on ouvre ce dossier et on colle le brief. On demande une première version locale avec de fausses données, et on l'essaie. Ensuite, on enregistre le code dans un dépôt privé. Pour une vraie application, on configure la base et les accès, puis on publie sur l'hébergeur et on raccorde le nom de domaine. Codex peut guider et préparer ces étapes ; il ne faut pas promettre qu'il crée les comptes ou choisit toutes les autorisations à votre place. Les identifiants secrets ne vont jamais dans le dépôt.


**À faire**

Ne pas créer les comptes ni attendre une propagation DNS en direct.


**Transition**

Après le premier résultat, on apprend en corrigeant.


**Sources :** [OpenAI : démarrage et dossier de travail](https://developers.openai.com/codex/quickstart/) ; [OpenAI : utiliser Codex avec son abonnement](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan) ; [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) ; [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing) ; [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security)

### 18. Une demande. Un test. Une version.

**18:15 - 19:10**


**À dire**

On n'a pas besoin d'avoir pensé à tout le premier jour. En utilisant le site, on va voir qu'un bouton est trop petit ou qu'il manque un filtre. On demande une modification à la fois. Pour un bug, la bonne description est très simple : voici ce que j'ai fait, voici ce qui s'est produit, voici ce que j'attendais. Et on demande un test qui empêche le problème de revenir. Le but n'est pas d'approuver tout ce que raconte l'agent : on clique soi-même et on vérifie le résultat.


**À faire**

Question possible à Loïc : quel comportement de débutant te ferait immédiatement dire stop ?


**Transition**

Il reste quelques vérifications avant d'inviter de vrais clients.

### 19. Vos clients ne sont pas des données de test.

**19:10 - 20:15**


**À dire**

Les faux clients de la démo ne deviennent pas de vrais clients par un simple copier-coller. Avant l'ouverture, on teste les accès : un utilisateur ne doit pas lire ou modifier les données des autres, et seul le commerçant doit créditer des points. On sauvegarde et on teste une restauration. On vérifie les textes d'information, les choix de conservation et les contrats des prestataires. Et on garde une validation humaine pour les campagnes. Quand on ne sait pas vérifier cela, se faire aider pour la mise en production est un bon investissement, pas un échec du projet.


**À faire**




**Transition**

Voilà comment je découperais la première demi-journée.


**Sources :** [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme) ; [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel) ; [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing)

### 20. Quatre heures pour un pilote.

**20:15 - 21:05**


**À dire**

Je commencerais par trente minutes à choisir le besoin. Puis une heure et demie sur les trois écrans utiles, une heure sur les règles, et une heure à tout essayer. C'est un découpage proposé, pas un temps mesuré pour tous les projets. Si à la fin on a un formulaire et une fidélité fiables en démo, mais pas encore les SMS, ce n'est pas grave. On réduit le périmètre, pas les vérifications. L'ouverture à de vrais clients reste une autre étape.


**À faire**




**Transition**

Je vois venir trois questions.

### 21. « Et si... »

**21:05 - 22:05**


**À dire**

Je n'y connais rien : justement, le premier exercice doit rester assez petit pour que vous puissiez expliquer vous-même ce qu'il doit faire. Je casse quelque chose : on garde une version stable et une sauvegarde des données, et on teste le retour en arrière. Je veux tout automatiser : on commence par comprendre le travail réel, puis on regarde les connexions disponibles avec la caisse ou le logiciel métier. Automatiser un mauvais processus, c'est surtout le reproduire plus vite. Et il faut savoir qui intervient si le site a un problème un samedi matin.


**À faire**

Laisser Nico ou Loïc choisir une objection. Utiliser la marge d'échanges si nécessaire.


**Transition**

La meilleure question pour commencer est beaucoup plus simple.

### 22. Commencez par la tâche qui vous fatigue.

**22:05 - 22:45**


**À dire**

Retenez surtout ça : ne commencez pas par vous demander quel outil d'IA utiliser. Commencez par la tâche que vous refaites, celle qui prend du temps ou qui vous fait oublier quelque chose. Décrivez-la, faites construire une petite version, essayez-la, puis améliorez-la. Dans le chat, dites-nous votre métier et la tâche dont vous avez marre. On peut prendre un exemple et voir ensemble quel premier outil aurait du sens.


**À faire**

Fin du parcours principal. Ne pas dérouler automatiquement les annexes.


**Transition**



## 6. Annexes pour les questions


### 23. Encore douze idées à creuser.

**hors parcours principal**


**À dire**

Ces exemples sont des idées de conception. Vérifier d'abord les fonctions déjà présentes dans les logiciels du professionnel. Les communications de service et les promotions ne se traitent pas de la même manière. Pour une première version, conserver une validation humaine et un périmètre simple. Ne pas inventer des avis, des photos de travaux réalisés, des disponibilités ou des prix.


**À faire**




**Transition**



### 24. La démo doit survivre au direct.

**hors parcours principal**


**À dire**

Le fichier de démo est autonome et ne dépend d'aucun service en ligne. Il conserve seulement des données fictives dans le navigateur. Son accès administrateur est simulé : il ne faut jamais le publier comme un vrai fichier clients. Les slides 8-10 constituent le plan B visuel. Le lecteur HTML propose N pour les notes sur l'écran courant et P pour une fenêtre présentateur séparée. Ne pas montrer la fenêtre de notes au public.


**À faire**




**Transition**



### 25. Le budget, sans raccourci.

**hors parcours principal**


**À dire**

Ces totaux sont des additions des prix affichés, pas des devis ni des budgets garantis. Scénario pilote : vingt plus vingt, soit quarante dollars par mois pendant la construction, avec une base gratuite limitée et une sauvegarde à organiser. Scénario base payante : ajouter vingt-cinq, soit soixante-cinq. Si l'outil n'appelle aucune IA, arrêter l'abonnement de création ne coupe pas à lui seul l'hébergement. Restent les mises à jour et le support. Cent SMS courts au tarif de six centimes hors taxes font six euros hors taxes, sept euros vingt TTC. Attention aux messages longs, aux emojis et aux caractères qui augmentent le nombre de segments facturés. Un nom de domaine n'est pas l'hébergement.


**À faire**




**Transition**




**Sources :** [OpenAI : tarifs Codex](https://chatgpt.com/codex/pricing/) ; [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing) ; [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/) ; [OVHcloud : segmentation des SMS et STOP](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/faq-sms) ; [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/) ; [OpenAI : prix et limites de ChatGPT Plus](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus) ; [OpenAI : les offres ChatGPT Pro](https://help.openai.com/en/articles/9793128-about-chatgpt-pro-tiers)

### 26. Avant de brancher de vrais clients.

**hors parcours principal**


**À dire**

Pour le passage en production, demander une revue technique proportionnée. Documenter les responsabilités et les prestataires, l'emplacement des données et les transferts éventuels. Une région européenne ne suffit pas à elle seule à résoudre tous les sujets. Tester les autorisations avec plusieurs identités et sans connexion. Tester aussi une restauration, pas seulement la présence d'un bouton sauvegarder. Le support décrit un petit outil de fidélité et ne remplace pas un conseil juridique adapté au commerce.


**À faire**




**Transition**




**Sources :** [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme) ; [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel) ; [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing) ; [OVHcloud : API SMS et liste de désinscription](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/api-sms-cookbook)

### 27. Les liens utiles.

**hors parcours principal**


**À dire**

Les noms, les prix et les interfaces sont susceptibles d'évoluer. Revérifier les pages officielles avant l'enregistrement. Les cas métier, le commerce fictif et le découpage en quatre heures sont des propositions pour cette émission, pas des statistiques ou des résultats observés. Tous les liens sont réunis dans le conducteur et dans les blocs Sources des notes PowerPoint.


**À faire**




**Transition**




**Sources :** [Support Sandbox, épisode 001](https://slides.sandboxpodcast.fr/episode-001/index.html) ; [OpenAI : tarifs Codex](https://chatgpt.com/codex/pricing/) ; [OpenAI : utiliser Codex avec son abonnement](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan) ; [OpenAI : démarrage et dossier de travail](https://developers.openai.com/codex/quickstart/) ; [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans) ; [GitHub : annuler une modification](https://docs.github.com/en/desktop/managing-commits/reverting-a-commit-in-github-desktop) ; [GitHub : sauvegarder un dépôt](https://docs.github.com/fr/repositories/archiving-a-github-repository/backing-up-a-repository) ; [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing) ; [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing) ; [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security) ; [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/) ; [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/) ; [OVHcloud : segmentation des SMS et STOP](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/faq-sms) ; [OVHcloud : API SMS et liste de désinscription](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/api-sms-cookbook) ; [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel) ; [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme)


## 7. Les questions qui risquent d'arriver

### Je n'ai jamais codé. Je peux vraiment commencer ?

Tu peux commencer par décrire un besoin et tester une version limitée. Ce n'est pas la même chose que savoir vérifier une application ouverte au public. Prévois un regard technique avant les données réelles, surtout pour les accès et les sauvegardes. Le bon premier objectif est un petit outil compréhensible, pas un logiciel métier complet.

### Pourquoi pas prendre un logiciel de fidélité déjà fait ?

C'est souvent la première chose à regarder. Vérifie les fonctions de ta caisse et de tes outils actuels. Le sur-mesure devient intéressant pour un besoin mal couvert ou un petit lien entre deux tâches. Il faut comparer le prix complet : construction, abonnement, maintenance et risques.

### C'est gratuit ou pas ?

La simulation locale fournie ici ne consomme aucun service payant. Un vrai service pour une boutique n'est pas gratuitement hébergé par Vercel Hobby. Le budget présenté distingue création, hébergement, données, domaine, SMS et maintenance. On ne confond pas euros et dollars, prix d'appel et renouvellement. Voir les slides 14 et 25 et leurs sources.

### Il faut garder ChatGPT payant pour que le site tourne ?

Pas pour servir ce type d'application sans appels d'IA : les règles de points sont du code classique. L'abonnement de création et les services qui font fonctionner le site sont deux choses différentes. Il reste à payer les services utilisés, et à assurer les corrections et mises à jour. Une fonction d'IA embarquée serait un cas distinct.

### GitHub me protège si tout casse ?

Il conserve les versions de code que tu as enregistrées et envoyées. Il ne sauvegarde pas automatiquement les clients et les achats présents dans la base. Revenir à un ancien code n'annule pas un SMS déjà envoyé ni une migration destructive de données. Il faut une sauvegarde distincte et savoir la restaurer. Sources GitHub en fin de conducteur.

### On peut connecter la caisse et ne plus rien saisir ?

Peut-être, selon le logiciel, ses accès et ses conditions. Commencer par regarder les fonctions existantes et la documentation du fournisseur. Une connexion demande de traiter les remboursements, doublons, annulations et interruptions. Ce n'est pas inclus dans notre prototype de quatre heures. Ne pas promettre une connexion universelle.

### On peut envoyer un SMS à tous les clients ?

Non. Pour ce prototype, le choix est simple : campagnes promotionnelles uniquement vers les personnes ayant explicitement accepté et n'ayant pas retiré leur accord. La CNIL décrit une exception encadrée pour des clients existants et des produits ou services analogues, mais une inscription seule ne suffit pas à en faire bénéficier. Ne pas résumer ce sujet à « on a son numéro, donc on peut envoyer ». Ajouter un vrai mécanisme de désinscription et tenir la liste des refus à jour. Voir la source CNIL.

### Je prends le domaine chez OVH, donc mes données restent en France ?

Non. Le domaine est l'adresse. Le lieu de stockage et les sous-traitants dépendent des services qui hébergent l'application et la base. Il faut examiner les régions choisies, les contrats, les transferts et les prestataires, pas seulement le vendeur du nom de domaine.

### Et les développeurs dans tout ça ?

Le sujet n'est pas de supprimer les vérifications techniques. L'IA rend une première version plus accessible. La robustesse, la sécurité, l'exploitation et les intégrations restent du travail. Un professionnel peut aider à cadrer et sécuriser un petit outil plutôt que tout refaire de zéro.

### Est-ce que l'IA peut choisir la remise et envoyer toute seule ?

Ce n'est pas le point de départ retenu. Anna choisit les règles et valide les messages. On commence par un brouillon et une prévisualisation, puis on automatise seulement un comportement compris et testé. La démo n'envoie rien automatiquement.

## 8. Vocabulaire simple à l'antenne

| Terme | Formulation orale |
|---|---|
| Prompt | La demande écrite qui explique le besoin et ce qu'on doit vérifier. |
| Codex | L'outil d'OpenAI qui travaille sur les fichiers du projet pour aider à le construire. |
| Dépôt GitHub | Le dossier de code avec son historique en ligne. |
| Commit | Un point d'enregistrement dans l'historique du code. |
| Déploiement | La publication d'une version sur l'hébergement. |
| Base de données | Le rangement des clients, achats et points, avec des droits d'accès. |
| Nom de domaine | L'adresse du site, pas la maison qui l'héberge. |
| Prototype | Une première version pour essayer et comprendre, pas encore une garantie de fiabilité. |

Préférer « les outils » à « le tooling » et « application de développement » à « harnais ». Ne pas dire que Codex est obligatoirement un abonnement distinct de ChatGPT.

## 9. Sources officielles

Consultation le 13 octobre 2026. Revoir les prix et limites peu avant l'enregistrement si la diffusion est décalée. Les idées de cas d'usage, le planning de quatre heures et les règles de fidélité sont des propositions éditoriales, pas des résultats mesurés.


- [Support Sandbox, épisode 001](https://slides.sandboxpodcast.fr/episode-001/index.html)

- [OpenAI : tarifs Codex](https://chatgpt.com/codex/pricing/)

- [OpenAI : utiliser Codex avec son abonnement](https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan)

- [OpenAI : démarrage et dossier de travail](https://developers.openai.com/codex/quickstart/)

- [GitHub : offres et dépôts privés](https://docs.github.com/en/get-started/learning-about-github/githubs-plans)

- [GitHub : annuler une modification](https://docs.github.com/en/desktop/managing-commits/reverting-a-commit-in-github-desktop)

- [GitHub : sauvegarder un dépôt](https://docs.github.com/fr/repositories/archiving-a-github-repository/backing-up-a-repository)

- [Vercel : tarifs et restriction du plan Hobby](https://vercel.com/pricing)

- [Supabase : prix, quotas et sauvegardes](https://supabase.com/pricing)

- [Supabase : contrôle des accès aux données](https://supabase.com/docs/guides/database/postgres/row-level-security)

- [OVHcloud : domaine .fr, création et renouvellement](https://www.ovhcloud.com/fr/domains/tld/fr/)

- [OVHcloud : tarifs des SMS en France](https://www.ovhcloud.com/fr/sms/prices/)

- [OVHcloud : segmentation des SMS et STOP](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/faq-sms)

- [OVHcloud : API SMS et liste de désinscription](https://docs.ovhcloud.com/fr/guides/web-cloud/messaging/sms/api-sms-cookbook)

- [CNIL : prospection par SMS et consentement](https://www.cnil.fr/fr/la-prospection-commerciale-par-courrier-electronique-sms-mms-et-automate-dappel)

- [CNIL : premiers repères pour les TPE-PME](https://www.cnil.fr/fr/thematiques/tpe-pme)

- [OpenAI : prix et limites de ChatGPT Plus](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus)

- [OpenAI : les offres ChatGPT Pro](https://help.openai.com/en/articles/9793128-about-chatgpt-pro-tiers)