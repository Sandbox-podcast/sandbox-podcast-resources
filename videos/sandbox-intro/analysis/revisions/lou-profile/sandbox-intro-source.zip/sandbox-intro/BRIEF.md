# Générique SANDBOX

Réalisation demandée par Lou le 14 octobre 2026. Source : brief joint et quatre images fournies. Livrable : générique complet en MP4 et projet Remotion modifiable.

- Durée : 63,56 s, issue du M4A Suno fourni.
- Master : 1920 x 1080, 50 images/s, H.264, AAC stéréo.
- Direction : collage photographique et dessins cartoon, fond noir bleuté, blanc, cyan, accents jaune et rouge pour les gags.
- Personnes : uniquement les photos de Lou, Loïc et Nico. Détourage par masques SVG éditables.
- Logo : fichier original intact, avec son A triangulaire cyan.
- Scènes : introduction, Lou, Loïc, Nico, Radar, Build, Clash, Bêta, final.
- Bande-son : source intégrale, sans montage, réécriture, accélération ni ajout sonore.
- Exécution autonome jusqu'au MP4. Aucun service payant supplémentaire, aucune publication.

La transcription locale Parakeet fournit les repères de paroles avec une résolution de 80 ms. La détection RMS situe les accents musicaux. Le storyboard est adapté au passage instrumental après Nico et à la fin réelle de la source. Les fichiers d'analyse conservent les données brutes et leurs limites.
